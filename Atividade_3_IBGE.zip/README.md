# Atividade 3 - Análise de Dados (IBGE - Tabela 3)

Este repositório contém os arquivos referentes à Atividade 3.

## Arquivos no projeto:
- `analise_tabela_3.py`: Script em Python contendo o código de processamento, divisão e cálculo com a função `.describe()`.
- `tabela_1_curso_superior.xlsx`: Tabela de pessoas por região com curso superior.
- `tabela_2_stem.xlsx`: Tabela de pessoas nas áreas de Ciência, Tecnologia, Engenharia e Matemática (STEM).
- `tabela_3_educacao_saude.xlsx`: Tabela de pessoas nas áreas de Educação, Serviços Pessoais, Saúde e Bem-estar.

## Como executar:
```bash
python analise_tabela_3.py
```
