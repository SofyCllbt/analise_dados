# Atividade 3 - Análise de Dados da Tabela 3 (IBGE)
import pandas as pd

# 1. Carregar os dados das regiões
dados = {
    'Regiao': ['Norte', 'Nordeste', 'Sudeste', 'Sul', 'Centro-Oeste'],
    'Superior_Homens': [590558, 1744994, 5391638, 1768855, 982489],
    'Superior_Mulheres': [1525166, 3003939, 7437191, 2570005, 1430013],
    'STEM_Homens': [133055, 389993, 1588874, 427372, 211124],
    'STEM_Mulheres': [76601, 231395, 739247, 235543, 115834],
    'Educa_Saude_Homens': [141169, 363905, 768288, 248574, 156048],
    'Educa_Saude_Mulheres': [458616, 1458181, 2884108, 1007718, 593101]
}

df = pd.DataFrame(dados)

# Divisão nas 3 tabelas
tabela_1 = df[['Regiao', 'Superior_Homens', 'Superior_Mulheres']].rename(columns={'Superior_Homens': 'Homens', 'Superior_Mulheres': 'Mulheres'})
tabela_2 = df[['Regiao', 'STEM_Homens', 'STEM_Mulheres']].rename(columns={'STEM_Homens': 'Homens', 'STEM_Mulheres': 'Mulheres'})
tabela_3 = df[['Regiao', 'Educa_Saude_Homens', 'Educa_Saude_Mulheres']].rename(columns={'Educa_Saude_Homens': 'Homens', 'Educa_Saude_Mulheres': 'Mulheres'})

# Salvando em arquivos XLSX
tabela_1.to_excel('tabela_1_curso_superior.xlsx', index=False)
tabela_2.to_excel('tabela_2_stem.xlsx', index=False)
tabela_3.to_excel('tabela_3_educacao_saude.xlsx', index=False)

print("--- Estatísticas da Tabela 1: Homens e Mulheres por Região com Curso Superior ---")
print(tabela_1.describe())
print("\n--- Estatísticas da Tabela 2: STEM (Ciência, Tecnologia, Engenharias e Matemática) ---")
print(tabela_2.describe())
print("\n--- Estatísticas da Tabela 3: Educação, Serviços, Saúde e Bem-estar ---")
print(tabela_3.describe())
