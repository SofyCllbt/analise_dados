import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(
    page_title="Cuidados e Afazeres Domésticos - IBGE",
    page_icon="🧺",
    layout="wide"
)

@st.cache_data
def carregar_dados():
    return pd.read_csv("dados.csv")

df = carregar_dados()

st.title("🧺 Cuidados e Afazeres Domésticos")
st.subheader("Número médio de horas semanais — IBGE")

st.info(
    "Dados da PNAD Contínua, referentes às pessoas de 14 anos ou mais "
    "de idade ocupadas na semana de referência."
)

col1, col2 = st.columns(2)

with col1:
    ano = st.selectbox(
        "Escolha o ano:",
        sorted(df["Ano"].unique(), reverse=True)
    )

with col2:
    localidades = sorted(df.loc[df["Ano"] == ano, "Localidade"].unique())
    localidade = st.selectbox("Escolha a localidade:", localidades)

dados = df[(df["Ano"] == ano) & (df["Localidade"] == localidade)].iloc[0]

st.markdown(f"### {localidade} — {ano}")

c1, c2, c3 = st.columns(3)
c1.metric("Total", f'{dados["Total"]:.1f} h/semana')
c2.metric("Homens", f'{dados["Homem"]:.1f} h/semana')
c3.metric("Mulheres", f'{dados["Mulher"]:.1f} h/semana')

grafico = pd.DataFrame({
    "Sexo": ["Homem", "Mulher"],
    "Horas": [dados["Homem"], dados["Mulher"]]
})

fig = px.bar(
    grafico,
    x="Sexo",
    y="Horas",
    text="Horas",
    title=f"Horas semanais por sexo — {localidade} ({ano})"
)
fig.update_traces(texttemplate="%{text:.1f}", textposition="outside")
fig.update_yaxes(title="Horas por semana")
fig.update_xaxes(title="Sexo")

st.plotly_chart(fig, use_container_width=True)

st.markdown("### Comparação entre anos")

comparacao = df[df["Localidade"] == localidade].sort_values("Ano")
fig2 = px.line(
    comparacao,
    x="Ano",
    y=["Total", "Homem", "Mulher"],
    markers=True,
    title=f"Evolução das horas semanais — {localidade}"
)
fig2.update_yaxes(title="Horas por semana")
fig2.update_xaxes(title="Ano")
st.plotly_chart(fig2, use_container_width=True)

st.caption(
    "Fonte: IBGE — Pesquisa Nacional por Amostra de Domicílios Contínua (PNAD Contínua)."
)
