# Deploy Streamlit — IBGE

## Arquivos
- `app.py`: aplicação Streamlit.
- `dados.csv`: dados extraídos da Tabela 1.1.2.
- `requirements.txt`: bibliotecas necessárias.

## Rodar localmente
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
1. Crie um repositório no GitHub.
2. Envie `app.py`, `dados.csv` e `requirements.txt`.
3. No Streamlit Community Cloud, escolha o repositório.
4. Branch: `main`.
5. Main file path: `app.py`.
6. Clique em Deploy.
